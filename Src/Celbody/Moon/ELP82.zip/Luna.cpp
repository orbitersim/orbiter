#include <math.h>
#include "Terms.dat"

void ELP82B (double tjj, double prec, double *r, int ierr)
{
	int i, ific, iv;
	double w[3][5], p[8][2], del[4][5], eart[5], peri[5], zeta[2], t[5], pre[3];
	double cpi, cpi2, pis2, rad, deg, c1, c2, ath, a0, am, alfa, dtasm, preces;
	double delnu, dele, delg, delnp, delep;
	double p1, p2, p3, p4, p5, q1, q2, q3, q4, q5, tgv, y;
	double x1, x2, x3, pw, qw, ra, pwqw, pw2, qw2;

	// Initialisation

	for (i = 0; i < 3; i++)
		r[i] = 0.0;
	cpi   = 3.141592653589793;
	cpi2  = 2.0*cpi;
	pis2  = cpi/2.0;
	rad   = 648000.0/cpi;
	deg   = cpi/180.0;
	c1    = 60.0;
    c2    = 3600.0;
    ath   = 384747.9806743165;
    a0    = 384747.9806448954;
    am    = 0.074801329518;
    alfa  = 0.002571881335;
    dtasm = 2.0*alfa/(3.0*am);

	// Lunar arguments

	w[0][0] = (218+18/c1+59.95571/c2)*deg;
    w[1][0] = (83+21/c1+11.67475/c2)*deg;
    w[2][0] = (125+2/c1+40.39816/c2)*deg;
    eart[0] = (100+27/c1+59.22059/c2)*deg;
    peri[0] = (102+56/c1+14.42753/c2)*deg;
    w[0][1] = 1732559343.73604/rad;
    w[1][1] = 14643420.2632/rad;
    w[2][1] = -6967919.3622/rad;
    eart[1] = 129597742.2758/rad;
    peri[1] = 1161.2283/rad;
    w[0][2] = -5.8883/rad;
    w[1][2] = -38.2776/rad;
    w[2][2] = 6.3622/rad;
    eart[2] = -0.0202/rad;
    peri[2] = 0.5327/rad;
    w[0][3] = 0.6604e-2/rad;
    w[1][3] = -0.45047e-1/rad;
    w[2][3] = 0.7625e-2/rad;
    eart[3] = 0.9e-5/rad;
    peri[3] = -0.138e-3/rad;
    w[0][4] = -0.3169e-4/rad;
    w[1][4] = 0.21301e-3/rad;
    w[2][4] = -0.3586e-4/rad;
    eart[4] = 0.15e-6/rad;
    peri[4] = 0.0;

	// Planetary arguments

    preces  = 5029.0966/rad;
    p[0][0] = (252+15/c1+3.25986/c2)*deg;
    p[1][0] = (181+58/c1+47.28305/c2)*deg;
    p[2][0] = eart[0];
    p[3][0] = (355+25/c1+59.78866/c2)*deg;
    p[4][0] = (34+21/c1+5.34212/c2)*deg;
    p[5][0] = (50+4/c1+38.89694/c2)*deg;
    p[6][0] = (314+3/c1+18.01841/c2)*deg;
    p[7][0] = (304+20/c1+55.19575/c2)*deg;
    p[0][1] = 538101628.68898/rad;
    p[1][1] = 210664136.43355/rad;
    p[2][1] = eart[1];
    p[3][1] = 68905077.59284/rad;
    p[4][1] = 10925660.42861/rad;
    p[5][1] = 4399609.65932/rad;
    p[6][1] = 1542481.19393/rad;
    p[7][1] = 786550.32074/rad;

	// Corrections of the constants (fit to DE200/LE200)

    delnu = +0.55604/rad/w[0][1];
    dele  = +0.01789/rad;
    delg  = -0.08066/rad;
    delnp = -0.06424/rad/w[0][1];
    delep = -0.12879/rad;

	// Delaunay's arguments

    for (i = 0; i < 5; i++) {
		del[0][i] = w[0][i] - eart[i];
		del[3][i] = w[0][i] - w[2][i];
		del[2][i] = w[0][i] - w[1][i];
		del[1][i] = eart[i] - peri[i];
	}
	del[0][0] = del[0][0] + cpi;
	zeta[0]   = w[0][0];
	zeta[1]   = w[0][1] + preces;

	// Precession matrix

	p1 =  0.10180391e-4;
	p2 =  0.47020439e-6;
	p3 = -0.5417367e-9;
	p4 = -0.2507948e-11;
	p5 =  0.463486e-14;
	q1 = -0.113469002e-3;
	q2 =  0.12372674e-6;
	q3 =  0.1265417e-8;
	q4 = -0.1371808e-11;
	q5 = -0.320334e-14;

	t[0]   = 1.0;
	t[1]   = (tjj-2451545.0)/36525.0;
	t[2]   = t[1]*t[1];
	t[3]   = t[2]*t[1];
	t[4]   = t[3]*t[1];
	pre[0] = prec*rad;
	pre[1] = prec*rad;
	pre[2] = prec*ath;
	ific = 1;
	ierr = 0;

	// Apply perturbation terms

	// Main problem
	for (ific = 1; ific <= 3; ific++) {

		int i, k, l, m;
		double x;
		MainBin lin;

		iv = ((ific-1) % 3) + 1;
		switch (ific) {
		case 1: m = N_MAIN_1; break;
		case 2: m = N_MAIN_2; break;
		case 3: m = N_MAIN_3; break;
		default: m = 0;
		}

		for (l = 1; l <= m; l++) {
			switch (ific) {
			case 1: lin = main_1[l-1];
			case 2: lin = main_2[l-1];
			case 3: lin = main_3[l-1];
			}
			x = lin.coef[0];
			if (fabs(x) < pre[iv-1]) continue;
			tgv = lin.coef[1] + dtasm*lin.coef[5];
            if (ific==3) lin.coef[0] -= 2.0*lin.coef[0]*delnu/3.0;
			x = lin.coef[0] + tgv*(delnp-am*delnu) + lin.coef[2]*delg +
				lin.coef[3]*dele + lin.coef[4]*delep;
			y = 0.0;
			for (k = 0; k < 5; k++) {
				for (i = 0; i < 4; i++) {
					y += lin.ilu[i]*del[i][k]*t[k];
				}
			}
			if (iv == 3) y += pis2;
			y = fmod (y,cpi2);
			r[iv-1] += x*sin(y);
		}
	}

	// Add: FiguresTides
	// Add: PlanetaryPerturbations
	// Add: FiguresTides

	// Change of coordinates

	r[0] = r[0]/rad+w[0][0]+w[0][1]*t[1]+w[0][2]*t[2]+w[0][3]*t[3]+w[0][4]*t[4];
	r[1] = r[1]/rad;
	r[2] = r[2]*a0/ath;
	x1   = r[2]*cos(r[1]);
	x2   = x1*sin(r[0]);
	x1   = x1*cos(r[0]);
	x3   = r[2]*sin(r[1]);
	pw   = (p1+p2*t[1]+p3*t[2]+p4*t[3]+p5*t[4])*t[1];
	qw   = (q1+q2*t[1]+q3*t[2]+q4*t[3]+q5*t[4])*t[1];
	ra   = 2.0*sqrt(1-pw*pw-qw*qw);
	pwqw = 2.0*pw*qw;
	pw2  = 1-2.0*pw*pw;
	qw2  = 1-2.0*qw*qw;
	pw   = pw*ra;
	qw   = qw*ra;
	r[0] = pw2*x1+pwqw*x2+pw*x3;
	r[1] = pwqw*x1+qw2*x2-qw*x3;
	r[2] = -pw*x1+qw*x2+(pw2+qw2-1)*x3;

}